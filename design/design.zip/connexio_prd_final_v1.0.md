# Product Requirement Document (PRD)
# Sistem Manajemen Inventaris Alat Pelanggan (Telco Lifecycle Tracker)
**Versi:** 1.0 (Final)  
**Tanggal:** 26 Mei 2026  
**Arsitektur Sistem:** Full Web-Based (Laravel + Tailwind CSS + JQuery)  
**Status:** Ready for Development

## 1. Ringkasan Eksekutif & Batasan Sistem
### 1.1 Tujuan Produk
Sistem ini bertindak sebagai Data Hub & Early Warning System terpusat untuk memantau siklus hidup (lifecycle) perangkat Modem dan STB yang digunakan oleh pelanggan melalui perantara teknisi lapangan. Fokus utama sistem adalah transparansi data audit, akurasi status inventaris, validasi fisik melalui foto, serta kemudahan navigasi teknisi.

### 1.2 Batasan Sistem (Out of Scope)
*   **Bukan Sistem Eksekutor WO:** Tidak mengelola tiket Work Order baru.
*   **Bukan Sistem Input Gudang Masal:** Tidak ada modul input stok baru secara masal dari pabrikan.

## 2. Manajemen Akses & Peran Pengguna (RBAC)
### 2.1 Admin (Desktop Web View)
*   Mengelola master data pelanggan dan pool perangkat.
*   Melakukan persetujuan (Approval/ACC) pada alur Pengambilan, Pengembalian, dan Dismantling.
*   Bypass Input data pelanggan baru.
*   Bulk Import data pelanggan via Excel dengan resolusi konflik.
*   Memantau Dashboard Early Warning System.

### 2.2 Teknisi (Mobile-First Responsive Web View)
*   Request pengambilan barang berdasarkan ID Pelanggan.
*   Konfirmasi pengambilan fisik.
*   Akses data detail & Google Maps (hanya jika status In Hand).
*   Input data lapangan (Upload Foto Bukti).

## 3. Spesifikasi Fungsional & Alur Kerja Core
### 3.1 Alur 1: Pengambilan & Pemasangan Barang (Deployment)
1. Teknisi request via ID Pelanggan.
2. Admin Approve dengan input SN & Jenis Barang.
3. Status: Ready to Pick Up.
4. Teknisi Konfirmasi Pengambilan (Status: In Hand).
5. Teknisi Pasang, Upload Foto, Selesai. (Status: Terpasang).

### 3.2 Alur 2: Pengembalian Barang (Return / Rusak)
1. Teknisi buka form Return, pilih ID Pelanggan & SN.
2. Teknisi isi alasan & Upload Foto. (Status: Pending Return Approval).
3. Admin verifikasi fisik & ACC. (Status: Rusak).

### 3.3 Alur 3: Dismantling (Pelanggan Putus Layanan)
1. Teknisi pilih ID Pelanggan, sistem tampilkan list SN terpasang.
2. Teknisi pilih perangkat & Upload Foto.
3. Admin verifikasi fisik & ACC. (Status: Terminated/Dismantling).

## 4. Fitur Mitigasi & Penanganan Kontingensi Data
### 4.1 Fitur Bypass Input Pelanggan
Pop-up form input darurat jika data pelanggan tidak ditemukan saat approval request.

### 4.2 Modul Bulk Import Excel & Resolusi Konflik
3 Tahap: Pre-Validation, Preview Modal (Side-by-Side Comparison), & Strategy Selection (Skip, Overwrite, Keep Both).

## 5. Fitur Dashboard Monitoring (Early Warning System)
*   View table khusus Admin Desktop.
*   **Priority Sorting:** Masa pakai terlama di atas.
*   **Visual Flagging:** Baris berubah warna Kuning Soft jika > 3 Tahun.

## 6. Struktur Arsitektur Data
*   Tabel: `customers`, `devices`, `users`, `assignments`.

## 7. Aturan Estetika & UX
*   **CTA Color:** Soft Blue (#2B6CB0).
*   **No Green:** Hijau ditiadakan total.
*   **Teknisi View:** Interactive Accordion Card (jQuery).